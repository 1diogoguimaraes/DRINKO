<template>
	<main id="Control-page" class="p-4">
		<div class="flex justify-between items-center mb-4">
			<h1 class="text-2xl font-bold">Control Panel</h1>
			<div class="flex gap-2">
				<button class="px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700" @click="openCreateModal">
					＋ Create Match
				</button>
				<button class="px-4 py-2 rounded bg-red-600 text-white hover:bg-red-700" @click="resetDevices">
					⟳ Reset All
				</button>
			</div>
		</div>
		<div class="grid grid-cols-2 gap-4">
			<!-- Unassigned -->
			<div class="border rounded-lg p-3 shadow">
				<h2 class="font-semibold mb-2">Unassigned</h2>
				<ul>
					<li v-for="d in unassigned" :key="d.device_id">
						{{ d.device_id }} ({{ d.status }})
					</li>
				</ul>
			</div>

			<!-- SOLO -->
			<div class="border rounded-lg p-3 shadow">
				<h2 class="font-semibold mb-2">Solo</h2>

				<div v-for="(devices, matchId) in soloByMatch" :key="matchId" class="mb-4">
					<h3 class="font-medium flex justify-between items-center">
						<span>Match {{ matchId }}</span>
						<button class="px-3 py-1 rounded bg-blue-500 text-white disabled:bg-gray-500"
							:disabled="!allLocked(devices)" @click="playMatch(matchId, 'solo')">
							▶ Play
						</button>
						<button class="px-3 py-1 rounded bg-yellow-500 text-white"
							@click="openEditModal(String(matchId))">
							✎ Edit
						</button>
						<button class="px-3 py-1 rounded bg-red-600 text-white disabled:bg-gray-500"
							:disabled="match.status !== 'finished'" @click="finalizeMatch(matchId)">
							✔ Finalize
						</button>



					</h3>
					<ul>
						<li v-for="d in devices" :key="d.device_id">
							{{ d.player_name ?? 'Unnamed Player' }}
							({{ d.device_id }}, {{ d.status }},
							start_weight: {{ d.start_weight ?? '-' }},
							end_weight: {{ d.end_weight ?? '-' }},
							reaction_time: {{ d.reaction_time_seconds ?? '-' }},
							time: {{ d.time_seconds ?? '-' }})
						</li>
					</ul>
				</div>
			</div>


			<!-- 1v1 -->
			<div class="border rounded-lg p-3 shadow">
				<h2 class="font-semibold mb-2">1v1</h2>

				<div v-for="(devices, matchId) in oneVsOneByMatch" :key="matchId" class="mb-4">
					<h3 class="font-medium flex justify-between items-center">
						<span>Match {{ matchId }}</span>
						<button class="px-3 py-1 rounded bg-blue-500 text-white disabled:bg-gray-500"
							:disabled="!allLocked(devices)" @click="playMatch(matchId, '1v1')">
							▶ Play
						</button>
						<button class="px-3 py-1 rounded bg-yellow-500 text-white"
							@click="openEditModal(String(matchId))">
							✎ Edit
						</button>
						<button class="px-3 py-1 rounded bg-red-600 text-white disabled:bg-gray-500"
							:disabled="match.status !== 'finished'" @click="finalizeMatch(matchId)">
							✔ Finalize
						</button>



					</h3>
					<table class="table-auto w-full">
						<thead>
							<tr>
								<th class="text-left">
									{{devices.find(d => d.team === 0)?.team_name ?? 'Team 0'}}
								</th>
								<th class="text-left">
									{{devices.find(d => d.team === 1)?.team_name ?? 'Team 1'}}
								</th>
							</tr>
						</thead>

						<tbody>
							<tr v-for="(row, idx) in makeTeamRows(devices)" :key="idx">
								<td v-if="row[0]">
									{{ row[0].name ?? 'Unnamed Player' }}
									({{ row[0].device_id }},
									pos {{ row[0].relay_pos }},
									{{ row[0].status }},
									start_weight:{{ row[0].start_weight ?? '-' }},
									end_weight:{{ row[0].end_weight ?? '-' }},
									reaction_time:{{ row[0].reaction_time_seconds ?? '-' }},
									time:{{ row[0].time_seconds ?? '-' }})
								</td>
								<td v-else></td>

								<td v-if="row[1]">
									{{ row[1].name ?? 'Unnamed Player' }}
									({{ row[1].device_id }}, pos {{ row[1].relay_pos }},
									{{ row[1].status }},
									start_weight:{{ row[1].start_weight ?? '-' }},
									end_weight:{{ row[1].end_weight ?? '-' }},
									reaction_time:{{ row[1].reaction_time_seconds ?? '-' }},
									time:{{ row[1].time_seconds ?? '-' }})
								</td>
								<td v-else></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>

			<!-- Relay -->
			<div class="border rounded-lg p-3 shadow">
				<h2 class="font-semibold mb-2">Relay</h2>

				<div v-for="(devices, matchId) in relayByMatch" :key="matchId" class="mb-4">
					<h3 class="font-medium flex justify-between items-center">
						<span>Match {{ matchId }}</span>
						<button class="px-3 py-1 rounded bg-blue-500 text-white disabled:bg-gray-500"
							:disabled="!allLocked(devices)" @click="playMatch(matchId, 'relay')">
							▶ Play
						</button>
						<button class="px-3 py-1 rounded bg-yellow-500 text-white"
							@click="openEditModal(String(matchId))">
							✎ Edit
						</button>
						<button class="px-3 py-1 rounded bg-red-600 text-white disabled:bg-gray-500"
							:disabled="match.status !== 'finished'" @click="finalizeMatch(matchId)">
							✔ Finalize
						</button>



					</h3>
					<table class="table-auto w-full">
						<thead>
							<tr>
								<th class="text-left">
									{{devices.find(d => d.team === 0)?.team_name ?? 'Team 0'}}
								</th>
								<th class="text-left">
									{{devices.find(d => d.team === 1)?.team_name ?? 'Team 1'}}
								</th>
							</tr>
						</thead>

						<tbody>
							<tr v-for="(row, idx) in makeTeamRows(devices)" :key="idx">
								<td v-if="row[0]">
									{{ row[0].name ?? 'Unnamed Player' }}
									({{ row[0].device_id }},
									pos {{ row[0].relay_pos }},
									{{ row[0].status }},
									start_weight:{{ row[0].start_weight ?? '-' }},
									end_weight:{{ row[0].end_weight ?? '-' }},
									reaction_time:{{ row[0].reaction_time_seconds ?? '-' }},
									time:{{ row[0].time_seconds ?? '-' }})
								</td>
								<td v-else></td>

								<td v-if="row[1]">
									{{ row[1].name ?? 'Unnamed Player' }}
									({{ row[1].device_id }},
									pos {{ row[1].relay_pos }},
									{{ row[1].status }},
									start_weight:{{ row[1].start_weight ?? '-' }},
									end_weight:{{ row[1].end_weight ?? '-' }},
									reaction_time:{{ row[1].reaction_time_seconds ?? '-' }},
									time:{{ row[1].time_seconds ?? '-' }})
								</td>
								<td v-else></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- Modal: Create Match -->
		<div v-if="showCreateModal" class="modal">
			<div class="modal-content">
				<h2 class="text-lg font-bold mb-3">Create Match</h2>

				<label class="block mb-2">Mode:</label>
				<select v-model="newMatchType" class="w-full p-2 mb-3 rounded bg-gray-800 text-white">
					<option value="solo">Solo</option>
					<option value="1v1">1v1</option>
					<option value="relay">Relay</option>
				</select>

				<!-- Device selection -->
				<!-- Device selection -->
				<div class="mb-3">
					<label class="block mb-2">Select Devices (unassigned only):</label>
					<div class="device-list">
						<button v-for="d in unassigned" :key="d.device_id" @click="toggleDevice(d.device_id)"
							:disabled="isDisabled(d.device_id)" :class="[
								'px-2 py-1 rounded',
								selectedDevices.includes(d.device_id)
									? 'bg-blue-600 text-white'
									: 'bg-gray-700 text-gray-200',
								isDisabled(d.device_id) ? 'opacity-50 cursor-not-allowed' : ''
							]">
							{{ d.device_id }}
						</button>
					</div>
				</div>

				<!-- Error message -->
				<p v-if="validationError" class="text-red-600 mt-2">{{ validationError }}</p>


				<div class="flex justify-end gap-2 mt-4">
					<button class="px-4 py-2 rounded bg-gray-600 text-white" @click="closeCreateModal">
						Cancel
					</button>
					<button class="px-4 py-2 rounded bg-blue-600 text-white" @click="createMatch">
						Create
					</button>
				</div>
			</div>
		</div>
		<!-- Modal: Edit Match -->
		<div v-if="showEditModal && editingMatch && editingMatch.teams" class="modal">
			<div class="modal-content">
				<h2 class="text-lg font-bold mb-3">Edit Match {{ editingMatchId }}</h2>

				<div v-for="(team, tIndex) in editingMatch.teams" :key="tIndex" class="mb-4">
					<label class="block mb-1">Team {{ tIndex }} Name:</label>
					<input v-model="team.team_name" class="w-full p-2 mb-2 rounded bg-gray-800 text-white"
						placeholder="Enter team name" />

					<div v-for="(player, pIndex) in team.players ?? []" :key="player.device_id" class="ml-4 mb-2">
						<label class="block">Player ({{ player.device_id }}):</label>
						<input v-model="player.player_name" class="w-full p-2 rounded bg-gray-700 text-white"
							placeholder="Enter player name" />
					</div>
				</div>

				<div class="flex justify-end gap-2 mt-4">
					<button class="px-4 py-2 rounded bg-gray-600 text-white" @click="closeEditModal">Cancel</button>
					<button class="px-4 py-2 rounded bg-blue-600 text-white" @click="saveEditMatch">Save</button>
				</div>
			</div>
		</div>


	</main>
</template>

<script setup>
import { reactive, ref, onMounted, onBeforeUnmount, computed } from 'vue'

const statuses = reactive({}) // device_id → status info
const players = ref({}) // device_id → player info
const matchesMemory = ref({}) // match_id → full match snapshot

let socketDevices = null
let socketPlayers = null

onMounted(() => {
	// --- Devices WebSocket ---
	socketDevices = new WebSocket('ws://localhost:8000/ws/live')
	socketDevices.onmessage = (event) => {
		const data = JSON.parse(event.data)
		if (data.type === 'devices_snapshot') {
			for (const [device_id, info] of Object.entries(data.devices)) {
				statuses[device_id] = {
					device_id,
					status: info.status ?? null,
					match: info.match_id ?? null,
					mode: info.mode ?? null,
					team: info.team != null ? Number(info.team) : null,
					relay_pos: info.relay_pos ?? null,
					battery: info.battery ?? null
				}
			}
		}
		if (data.type === 'status') {
			statuses[data.device_id] = {
				device_id: data.device_id,
				status: data.status,
				match: data.match_id,
				mode: data.mode,
				team: Number(data.team),
				relay_pos: data.relay_pos,
				battery: data.battery
			}
			statuses[data.device_id] = { ...statuses[data.device_id] }
		}
	}

	socketPlayers = new WebSocket('ws://localhost:8000/ws/matches')

	socketPlayers.onmessage = (event) => {
		const data = JSON.parse(event.data)
		console.log(data)
		if (data.type === 'matches_snapshot' || data.type === 'matches_update') {
			const incoming = data.data ?? {}

			// Replace the object safely
			matchesMemory.value = { ...matchesMemory.value, ...incoming }

			// Update players map
			let updatedPlayers = { ...players.value }

			for (const [matchId, match] of Object.entries(incoming)) {
				if (Array.isArray(match.teams)) {
					for (const team of match.teams) {
						for (const player of team.players ?? []) {
							updatedPlayers[player.device_id] = {
								player_name: player.player_name ?? null,
								team_name: team.team_name ?? null,
								start_weight: player.start_weight ?? null,
								end_weight: player.end_weight ?? null,
								reaction_time_seconds: player.reaction_time_seconds ?? null,
								time_seconds: player.time_seconds ?? null,
								foul: player.foul ?? false
							}
						}
					}
				}
			}

			players.value = updatedPlayers
		}

	}





})

onBeforeUnmount(() => {
	if (socketDevices) socketDevices.close()
	if (socketPlayers) socketPlayers.close()
})

// merge device + player info
function mergeDevice(d) {
	return { ...d, ...(players[d.device_id] || {}) }
}

// categories with merged data
const unassigned = computed(() =>
	Object.values(statuses).filter((d) => !d.mode).map(mergeDevice)
)
const solo = computed(() =>
	Object.values(statuses).filter((d) => d.mode === 'solo').map(mergeDevice)
)
const oneVsOne = computed(() =>
	Object.values(statuses).filter((d) => d.mode === '1v1').map(mergeDevice)
)
const relay = computed(() =>
	Object.values(statuses).filter((d) => d.mode === 'relay').map(mergeDevice)
)

// group by match_id
function groupByMatch(devices) {
	return devices.reduce((acc, d) => {
		const matchId = d.match ?? 'unassigned'
		if (!acc[matchId]) acc[matchId] = []
		acc[matchId].push(d)
		return acc
	}, {})
}

function makeTeamRows(devices) {
	const team0 = devices.filter((r) => r.team === 0).sort((a, b) => a.relay_pos - b.relay_pos)
	const team1 = devices.filter((r) => r.team === 1).sort((a, b) => a.relay_pos - b.relay_pos)

	const maxLen = Math.max(team0.length, team1.length)
	const rows = []
	for (let i = 0; i < maxLen; i++) {
		rows.push([team0[i] || null, team1[i] || null])
	}
	return rows
}




// --- Solo matches from matchesMemory ---
const soloByMatch = computed(() => {
	const result = {}
	for (const [matchId, match] of Object.entries(matchesMemory.value)) {
		if (match.match_type === "solo") {
			const players = []
			match.teams.forEach((team, teamIndex) => {
				team.players.forEach((p) => {
					players.push({
						...p,
						team: teamIndex,
						team_name: team.team_name
					})
				})
			})
			result[matchId] = players
		}
	}
	return result
})

// --- 1v1 matches ---
const oneVsOneByMatch = computed(() => {
	const result = {}
	for (const [matchId, match] of Object.entries(matchesMemory.value)) {
		if (match.match_type === "1v1") {
			const players = []
			match.teams.forEach((team, teamIndex) => {
				const teamName = team.team_name ?? `Team ${teamIndex}`
				team.players.forEach((p) => {
					players.push({
						...p,
						team: teamIndex,
						team_name: teamName,
						relay_pos: p.relay_pos ?? 0
					})
				})
			})
			result[matchId] = players
		}
	}
	return result
})

// --- Relay matches ---
const relayByMatch = computed(() => {
	const result = {}
	for (const [matchId, match] of Object.entries(matchesMemory.value)) {
		if (match.match_type === "relay") {
			const players = []
			match.teams.forEach((team, teamIndex) => {
				const teamName = team.team_name ?? `Team ${teamIndex}`
				team.players.forEach((p) => {
					players.push({
						...p,
						team: teamIndex,
						team_name: teamName,
						relay_pos: p.relay_pos ?? 0
					})
				})
			})
			result[matchId] = players
		}
	}
	return result
})



function allLocked(devices) {
	return devices.length > 0 && devices.every((d) => d.status === 'locked')
}

async function playMatch(matchId, mode) {
	try {
		const res = await fetch(`http://localhost:8000/matches/${matchId}/start`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ mode })
		})
		if (!res.ok) throw new Error(`Failed to start match ${matchId}`)
		console.log(`✅ Match ${matchId} (${mode}) started`)
	} catch (err) {
		console.error(err)
		alert(`Error: ${err.message}`)
	}
}

async function resetDevices() {
	try {
		const res = await fetch('http://localhost:8000/devices/reset', {
			method: 'POST'
		})
		if (!res.ok) throw new Error('Failed to reset devices')
		console.log('✅ Reset signal sent to all devices')
	} catch (err) {
		console.error(err)
		alert(`Error: ${err.message}`)
	}
}

// Modal state
const showCreateModal = ref(false)
const newMatchType = ref('solo')
const selectedDevices = ref([])

function openCreateModal() {
	showCreateModal.value = true
	selectedDevices.value = []
	newMatchType.value = 'solo'
}
function closeCreateModal() {
	showCreateModal.value = false
	selectedDevices.value = []
}

// toggle device in selection
function toggleDevice(deviceId) {
	if (selectedDevices.value.includes(deviceId)) {
		selectedDevices.value = selectedDevices.value.filter((id) => id !== deviceId)
	} else {
		selectedDevices.value.push(deviceId)
	}
}

// Build player object
function buildPlayer(deviceId) {
	return {
		device_id: deviceId,
		status: 'none',
		player_name: null,
		time_seconds: null,
		reaction_time_seconds: null,
		start_weight: null,
		end_weight: null,
		foul: false
	}
}


const validationError = ref(null)

// Disable devices if already at limit for mode
function isDisabled(deviceId) {
	if (newMatchType.value === 'solo') {
		return selectedDevices.value.length >= 1 && !selectedDevices.value.includes(deviceId)
	}
	if (newMatchType.value === '1v1') {
		return selectedDevices.value.length >= 2 && !selectedDevices.value.includes(deviceId)
	}
	if (newMatchType.value === 'relay') {
		// max 10 (5 per team)
		return selectedDevices.value.length >= 10 && !selectedDevices.value.includes(deviceId)
	}
	return false
}

// Enforce rules on create
async function createMatch() {
	validationError.value = null

	if (newMatchType.value === 'solo' && selectedDevices.value.length !== 1) {
		validationError.value = 'Solo match requires exactly 1 device.'
		return
	}
	if (newMatchType.value === '1v1' && selectedDevices.value.length !== 2) {
		validationError.value = '1v1 match requires exactly 2 devices.'
		return
	}
	if (newMatchType.value === 'relay') {
		if (selectedDevices.value.length !== 4 && selectedDevices.value.length !== 10) {
			validationError.value = 'Relay must have 2 or 5 devices per team (total 4 or 10).'
			return
		}
	}

	try {
		const payload = buildMatchPayload(newMatchType.value, selectedDevices.value)
		const res = await fetch('http://localhost:8000/matches/', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(payload)
		})
		if (!res.ok) throw new Error('Failed to create match')
		console.log('✅ Match created', payload)
		closeCreateModal()
	} catch (err) {
		console.error(err)
		alert(`Error: ${err.message}`)
	}
}

// Build JSON payload (small tweak for relay validation)
function buildMatchPayload(type, devices) {
	if (type === 'solo') {
		return {
			match_type: 'solo',
			teams: [
				{
					team_name: null,
					finished: false,
					players: [buildPlayer(devices[0])]
				}
			]
		}
	}

	if (type === '1v1') {
		return {
			match_type: '1v1',
			teams: [
				{ team_name: null, finished: false, players: [buildPlayer(devices[0])] },
				{ team_name: null, finished: false, players: [buildPlayer(devices[1])] }
			]
		}
	}

	if (type === 'relay') {
		const half = devices.length / 2 // safe because already validated
		return {
			match_type: 'relay',
			teams: [
				{ team_name: null, finished: false, players: devices.slice(0, half).map(buildPlayer) },
				{ team_name: null, finished: false, players: devices.slice(half).map(buildPlayer) }
			]
		}
	}
}

// --- Edit Modal State ---
const showEditModal = ref(false)
const editingMatchId = ref(null)
const editingMatch = ref(null) // store full match object for editing

function openEditModal(matchId) {
	const match = matchesMemory.value[String(matchId)]
	if (!match) {
		alert("Match not found in memory")
		return
	}
	editingMatchId.value = String(matchId)
	editingMatch.value = JSON.parse(JSON.stringify(match))
	showEditModal.value = true
}



function closeEditModal() {
	showEditModal.value = false
	editingMatchId.value = null
	editingMatch.value = null
}

async function saveEditMatch() {
	try {
		const payload = editingMatch.value
		const res = await fetch(`http://localhost:8000/matches/${editingMatchId.value}/update`, {
			method: 'PATCH',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(payload)
		})
		if (!res.ok) throw new Error('Failed to update match')
		console.log('✅ Match updated', payload)
		closeEditModal()
	} catch (err) {
		console.error(err)
		alert(`Error: ${err.message}`)
	}
}
async function finalizeMatch(matchId) {
	try {
		const res = await fetch(`http://localhost:8000/matches/${matchId}/finalize`, {
			method: "POST"
		})
		if (!res.ok) throw new Error(`Failed to finalize match ${matchId}`)

		const data = await res.json()
		console.log("✅ Match finalized", data)

		// Optimistic update: remove from matchesMemory
		const newMem = { ...matchesMemory.value }
		delete newMem[matchId]
		matchesMemory.value = newMem

		alert(`Match ${matchId} finalized and saved!`)
	} catch (err) {
		console.error(err)
		alert(`Error: ${err.message}`)
	}
}

</script>

<style scoped>
.columns {
	display: flex;
	gap: 1rem;
	margin: 1rem 0;
}

.column {
	flex: 1;
	background: #1b1b1b;
	padding: 1rem;
	border-radius: 8px;
}

.game {
	margin-bottom: 1rem;
	padding: 0.5rem;
	background: #333;
	border-radius: 5px;
}

.player {
	display: flex;
	justify-content: space-between;
	background: #444;
	margin: 0.25rem 0;
	padding: 0.25rem 0.5rem;
	border-radius: 3px;
}

button.create {
	margin-top: 1rem;
}

.modal {
	position: fixed;
	inset: 0;
	background: rgba(0, 0, 0, 0.7);
	display: flex;
	align-items: center;
	justify-content: center;
}

.modal-content {
	background: #e8e8e8;
	padding: 1rem;
	border-radius: 8px;
	width: 400px;
}

.device-list {
	display: flex;
	flex-wrap: wrap;
	gap: 0.5rem;
}
</style>
